## 2026-07-03 02:44:59.476Z load
- url: https://570374f9-5359-45cb-b747-10ed49533294.app-preview.com/?t=1783046697825
- title: TOPOSIG S.A.S. | Consultoría ambiental y geomática

## 2026-07-03 02:45:01.416Z navigate
- url: https://570374f9-5359-45cb-b747-10ed49533294.app-preview.com/?t=1783046697825
- via: replaceState

## 2026-07-03 02:45:01.427Z console.error
- text: 
    Warning: React does not recognize the `%s` prop on a DOM element. If you intentionally want it to appear in the DOM as a custom attribute, spell it as lowercase `%s` instead. If you accidentally passed it from a parent component, remove it from the DOM element.%s fetchPriority fetchpriority 
        at img
        at div
        at section
        at Hero
        at main
        at div
        at HomePage
        at RenderedRoute (https://570374f9-5359-45cb-b747-10ed49533294.app-preview.com/node_modules/.vite/deps/react-router-dom.js?v=7c4dd836:6647:26)
        at Routes (https://570374f9-5359-45cb-b747-10ed49533294.app-preview.com/node_modules/.vite/deps/react-router-dom.js?v=7c4dd836:7572:3)
        at Router (https://570374f9-5359-45cb-b747-10ed49533294.app-preview.com/node_modules/.vite/deps/react-router-dom.js?v=7c4dd836:7511:13)
        at BrowserRouter (https://570374f9-5359-45cb-b747-10ed49533294.app-preview.com/node_modules/.vite/deps/react-router-dom.js?v=7c4dd836:10816:3)
        at App

## 2026-07-03 02:45:06.036Z click
- element: {"tag":"button","role":"tab","ariaLabel":null,"name":null,"type":null,"id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":" Ingeniería y Topografía"}

## 2026-07-03 02:45:07.316Z click
- element: {"tag":"button","role":"tab","ariaLabel":null,"name":null,"type":null,"id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":" SIG y Cartografía"}

## 2026-07-03 02:45:22.406Z focus
- element: {"tag":"input","role":null,"ariaLabel":"Buscar artículos","name":null,"type":"search","id":null,"placeholder":"Buscar artículos...","label":"Buscar artículos","value":"","valueLength":0,"text":""}

## 2026-07-03 02:45:22.499Z click
- element: {"tag":"input","role":null,"ariaLabel":"Buscar artículos","name":null,"type":"search","id":null,"placeholder":"Buscar artículos...","label":"Buscar artículos","value":"","valueLength":0,"text":""}

## 2026-07-03 02:45:48.972Z click
- element: {"tag":"div","role":null,"ariaLabel":null,"name":null,"type":null,"id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":" Consultoría ambiental y geomáticaPrecisión geoespacial para un desarrollo sostenibleIntegramos consultoría ambiental, geomática, LiDAR, SIG, geodesia y topografía de alta precisión para llevar sus proyectos de infraestructura a otro nivel.Nuestros servicios Solicitar cotización15+Años de experiencia320+Proyectos entregados98%Precisión certificada24Departamentos atendidos"}

## 2026-07-03 02:45:52.764Z click
- element: {"tag":"dt","role":null,"ariaLabel":null,"name":null,"type":null,"id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":"320+"}

## 2026-07-03 02:45:54.684Z click
- element: {"tag":"dt","role":null,"ariaLabel":null,"name":null,"type":null,"id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":"98%"}

## 2026-07-03 02:45:56.300Z click
- element: {"tag":"button","role":null,"ariaLabel":null,"name":null,"type":null,"id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":" Solicitar cotización"}

## 2026-07-03 02:45:58.172Z click
- element: {"tag":"div","role":null,"ariaLabel":null,"name":null,"type":null,"id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":"Nuestros servicios Solicitar cotización"}

## 2026-07-03 02:46:09.093Z focus
- element: {"tag":"input","role":null,"ariaLabel":"Buscar artículos","name":null,"type":"search","id":null,"placeholder":"Buscar artículos...","label":"Buscar artículos","value":"","valueLength":0,"text":""}

## 2026-07-03 02:46:09.156Z click
- element: {"tag":"input","role":null,"ariaLabel":"Buscar artículos","name":null,"type":"search","id":null,"placeholder":"Buscar artículos...","label":"Buscar artículos","value":"","valueLength":0,"text":""}

## 2026-07-03 02:46:14.356Z click
- element: {"tag":"p","role":null,"ariaLabel":null,"name":null,"type":null,"id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":"Calle 100 # 8A-55, Bogotá D.C., Colombia"}

## 2026-07-03 02:46:15.292Z click
- element: {"tag":"svg","role":null,"ariaLabel":null,"name":null,"type":null,"id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":""}

## 2026-07-03 02:46:15.675Z click
- element: {"tag":"p","role":null,"ariaLabel":null,"name":null,"type":null,"id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":"Calle 100 # 8A-55, Bogotá D.C., Colombia"}

## 2026-07-03 02:46:15.883Z click
- element: {"tag":"p","role":null,"ariaLabel":null,"name":null,"type":null,"id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":"Calle 100 # 8A-55, Bogotá D.C., Colombia"}

## 2026-07-03 02:46:16.060Z click
- element: {"tag":"p","role":null,"ariaLabel":null,"name":null,"type":null,"id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":"Calle 100 # 8A-55, Bogotá D.C., Colombia"}

## 2026-07-03 02:46:23.828Z click
- element: {"tag":"div","role":null,"ariaLabel":null,"name":null,"type":null,"id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":"ContactoHablemos de su próximo proyectoNuestro equipo técnico está listo para asesorarle. Escríbanos y le responderemos a la brevedad.Teléfono+57 300 123 4567Correocontacto@toposig.com.coOficinaCalle 100 # 8A-55, Bogotá D.C., ColombiaHorarioLun – Vie: 8:00 a.m. – 6:00 p.m. Escríbenos por WhatsApp"}

## 2026-07-03 02:46:39.913Z load
- url: https://570374f9-5359-45cb-b747-10ed49533294.app-preview.com/
- title: TOPOSIG S.A.S. | Consultoría ambiental y geomática

## 2026-07-03 02:46:41.501Z navigate
- url: https://570374f9-5359-45cb-b747-10ed49533294.app-preview.com/
- via: replaceState

## 2026-07-03 02:46:41.511Z console.error
- text: 
    Warning: React does not recognize the `%s` prop on a DOM element. If you intentionally want it to appear in the DOM as a custom attribute, spell it as lowercase `%s` instead. If you accidentally passed it from a parent component, remove it from the DOM element.%s fetchPriority fetchpriority 
        at img
        at div
        at section
        at Hero
        at main
        at div
        at HomePage
        at RenderedRoute (https://570374f9-5359-45cb-b747-10ed49533294.app-preview.com/node_modules/.vite/deps/react-router-dom.js?v=7c4dd836:6647:26)
        at Routes (https://570374f9-5359-45cb-b747-10ed49533294.app-preview.com/node_modules/.vite/deps/react-router-dom.js?v=7c4dd836:7572:3)
        at Router (https://570374f9-5359-45cb-b747-10ed49533294.app-preview.com/node_modules/.vite/deps/react-router-dom.js?v=7c4dd836:7511:13)
        at BrowserRouter (https://570374f9-5359-45cb-b747-10ed49533294.app-preview.com/node_modules/.vite/deps/react-router-dom.js?v=7c4dd836:10816:3)
        at App

## 2026-07-03 02:46:52.164Z click
- element: {"tag":"a","role":null,"ariaLabel":null,"name":null,"type":null,"id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":"Cómo la tecnología LiDAR está transformando la topografía moderna"}

## 2026-07-03 02:46:52.165Z navigate
- url: https://570374f9-5359-45cb-b747-10ed49533294.app-preview.com/blog/lidar-cambia-topografia
- via: pushState

## 2026-07-03 02:47:04.820Z click
- element: {"tag":"a","role":null,"ariaLabel":null,"name":null,"type":null,"id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":" Portal corporativo"}

## 2026-07-03 02:47:04.821Z navigate
- url: https://570374f9-5359-45cb-b747-10ed49533294.app-preview.com/blog/lidar-cambia-topografia#
- via: popstate

## 2026-07-03 02:47:07.252Z click
- element: {"tag":"a","role":null,"ariaLabel":null,"name":null,"type":null,"id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":" Portal corporativo"}

## 2026-07-03 02:47:07.252Z navigate
- url: https://570374f9-5359-45cb-b747-10ed49533294.app-preview.com/blog/lidar-cambia-topografia#
- via: popstate

## 2026-07-03 02:47:08.916Z click
- element: {"tag":"button","role":null,"ariaLabel":null,"name":null,"type":null,"id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":"Inicio"}

## 2026-07-03 02:47:08.916Z navigate
- url: https://570374f9-5359-45cb-b747-10ed49533294.app-preview.com/
- via: pushState

## 2026-07-03 02:47:11.276Z click
- element: {"tag":"a","role":null,"ariaLabel":null,"name":null,"type":null,"id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":" Portal corporativo"}

## 2026-07-03 02:47:11.276Z navigate
- url: https://570374f9-5359-45cb-b747-10ed49533294.app-preview.com/#
- via: popstate

## 2026-07-03 02:47:31.007Z load
- url: https://570374f9-5359-45cb-b747-10ed49533294.app-preview.com/?t=1783046697825
- title: TOPOSIG S.A.S. | Consultoría ambiental y geomática

## 2026-07-03 02:47:31.795Z navigate
- url: https://570374f9-5359-45cb-b747-10ed49533294.app-preview.com/?t=1783046697825
- via: replaceState

## 2026-07-03 02:47:31.798Z console.error
- text: 
    Warning: React does not recognize the `%s` prop on a DOM element. If you intentionally want it to appear in the DOM as a custom attribute, spell it as lowercase `%s` instead. If you accidentally passed it from a parent component, remove it from the DOM element.%s fetchPriority fetchpriority 
        at img
        at div
        at section
        at Hero
        at main
        at div
        at HomePage
        at RenderedRoute (https://570374f9-5359-45cb-b747-10ed49533294.app-preview.com/node_modules/.vite/deps/react-router-dom.js?v=7c4dd836:6647:26)
        at Routes (https://570374f9-5359-45cb-b747-10ed49533294.app-preview.com/node_modules/.vite/deps/react-router-dom.js?v=7c4dd836:7572:3)
        at Router (https://570374f9-5359-45cb-b747-10ed49533294.app-preview.com/node_modules/.vite/deps/react-router-dom.js?v=7c4dd836:7511:13)
        at BrowserRouter (https://570374f9-5359-45cb-b747-10ed49533294.app-preview.com/node_modules/.vite/deps/react-router-dom.js?v=7c4dd836:10816:3)
        at App

## 2026-07-03 02:49:17.705Z load
- url: https://570374f9-5359-45cb-b747-10ed49533294.app-preview.com/?t=1783046697825
- title: TOPOSIG S.A.S. | Consultoría ambiental y geomática

## 2026-07-03 02:49:18.575Z navigate
- url: https://570374f9-5359-45cb-b747-10ed49533294.app-preview.com/?t=1783046697825
- via: replaceState

## 2026-07-03 02:49:18.580Z console.error
- text: 
    Warning: React does not recognize the `%s` prop on a DOM element. If you intentionally want it to appear in the DOM as a custom attribute, spell it as lowercase `%s` instead. If you accidentally passed it from a parent component, remove it from the DOM element.%s fetchPriority fetchpriority 
        at img
        at div
        at section
        at Hero
        at main
        at div
        at HomePage
        at RenderedRoute (https://570374f9-5359-45cb-b747-10ed49533294.app-preview.com/node_modules/.vite/deps/react-router-dom.js?v=7c4dd836:6647:26)
        at Routes (https://570374f9-5359-45cb-b747-10ed49533294.app-preview.com/node_modules/.vite/deps/react-router-dom.js?v=7c4dd836:7572:3)
        at Router (https://570374f9-5359-45cb-b747-10ed49533294.app-preview.com/node_modules/.vite/deps/react-router-dom.js?v=7c4dd836:7511:13)
        at BrowserRouter (https://570374f9-5359-45cb-b747-10ed49533294.app-preview.com/node_modules/.vite/deps/react-router-dom.js?v=7c4dd836:10816:3)
        at App

## 2026-07-03 02:49:22.286Z navigate
- url: https://570374f9-5359-45cb-b747-10ed49533294.app-preview.com/
- via: replaceState

## 2026-07-03 02:49:22.286Z navigate
- url: https://570374f9-5359-45cb-b747-10ed49533294.app-preview.com/
- via: popstate

## 2026-07-03 02:51:13.185Z load
- url: https://570374f9-5359-45cb-b747-10ed49533294.app-preview.com/#
- title: TOPOSIG S.A.S. | Consultoría ambiental y geomática

## 2026-07-03 02:51:14.507Z navigate
- url: https://570374f9-5359-45cb-b747-10ed49533294.app-preview.com/#
- via: replaceState

## 2026-07-03 02:51:14.511Z console.error
- text: 
    Warning: React does not recognize the `%s` prop on a DOM element. If you intentionally want it to appear in the DOM as a custom attribute, spell it as lowercase `%s` instead. If you accidentally passed it from a parent component, remove it from the DOM element.%s fetchPriority fetchpriority 
        at img
        at div
        at section
        at Hero
        at main
        at div
        at HomePage
        at RenderedRoute (https://570374f9-5359-45cb-b747-10ed49533294.app-preview.com/node_modules/.vite/deps/react-router-dom.js?v=7c4dd836:6647:26)
        at Routes (https://570374f9-5359-45cb-b747-10ed49533294.app-preview.com/node_modules/.vite/deps/react-router-dom.js?v=7c4dd836:7572:3)
        at Router (https://570374f9-5359-45cb-b747-10ed49533294.app-preview.com/node_modules/.vite/deps/react-router-dom.js?v=7c4dd836:7511:13)
        at BrowserRouter (https://570374f9-5359-45cb-b747-10ed49533294.app-preview.com/node_modules/.vite/deps/react-router-dom.js?v=7c4dd836:10816:3)
        at App

## 2026-07-03 02:56:37.209Z load
- url: https://570374f9-5359-45cb-b747-10ed49533294.app-preview.com/#
- title: TOPOSIG S.A.S. | Consultoría ambiental y geomática

## 2026-07-03 02:56:38.480Z console.error
- text: 
    Warning: React does not recognize the `%s` prop on a DOM element. If you intentionally want it to appear in the DOM as a custom attribute, spell it as lowercase `%s` instead. If you accidentally passed it from a parent component, remove it from the DOM element.%s fetchPriority fetchpriority 
        at img
        at div
        at section
        at Hero
        at main
        at div
        at HomePage
        at RenderedRoute (https://570374f9-5359-45cb-b747-10ed49533294.app-preview.com/node_modules/.vite/deps/react-router-dom.js?v=7c4dd836:6647:26)
        at Routes (https://570374f9-5359-45cb-b747-10ed49533294.app-preview.com/node_modules/.vite/deps/react-router-dom.js?v=7c4dd836:7572:3)
        at Router (https://570374f9-5359-45cb-b747-10ed49533294.app-preview.com/node_modules/.vite/deps/react-router-dom.js?v=7c4dd836:7511:13)
        at BrowserRouter (https://570374f9-5359-45cb-b747-10ed49533294.app-preview.com/node_modules/.vite/deps/react-router-dom.js?v=7c4dd836:10816:3)
        at App

