# Codebase Map

npm workspaces monorepo at `/home/${username}/websites/${sandboxId}/public_html`. The web app ships standalone. Call `enable_pocketbase_integration` to add a database, or `enable_api_server_integration` to add an Express backend — each tool appends its own `## apps/<service>` section to this file.

## apps/web (React + Vite + Tailwind + shadcn/ui, port 3000)

Located at apps/web/. Run: `cd apps/web && npm run dev` (auto-started by the sandbox supervisor).
src/main.jsx — entry point, mounts <App />
src/App.jsx — React Router, all routes defined here
src/index.css — Tailwind theme with Emerald (#10b981) primary, Blue (#3b82f6) secondary, Montserrat headings, Inter body, CSS variables
src/pages/HomePage.jsx — "/" route, premium landing page with hero, services, about, differentiators, blog, contact sections
src/pages/BlogPage.jsx — "/blog" route, searchable/filterable blog with pagination
src/pages/ArticlePage.jsx — "/blog/:slug" route, individual article page with metadata
src/components/Header.jsx — sticky navigation with transparent-to-blur transition, active section highlighting, mobile menu
src/components/Hero.jsx — LiDAR/environmental consulting hero with dual CTAs and statistics
src/components/Services.jsx — interactive tabs for Environmental Consulting, Engineering & Surveying, GIS & Cartography
src/components/About.jsx — company history, mission, vision, quality policy cards
src/components/Differentiators.jsx — six premium cards: ANLA/IGAC compliance, LiDAR/UAV, precision surveying, strategic consulting, sustainability, operational efficiency
src/components/Blog.jsx — modern article cards with categories, search, filter, pagination
src/components/Contact.jsx — professional contact form with validation, contact info cards, WhatsApp CTA
src/components/Footer.jsx — dark professional footer with navigation, social links, copyright, corporate login
src/components/Reveal.jsx — scroll-triggered reveal animation component
src/components/ScrollToTop.jsx — resets scroll on route change
src/components/ui/ — shadcn/ui primitives — import from `@/components/ui/<name>`, do not edit the files
src/hooks/use-mobile.jsx — mobile breakpoint detection
src/hooks/use-toast.js — toast notifications
src/data/site.js — centralized site content: hero, services, about, differentiators, blog articles, contact info
src/lib/utils.js — cn() Tailwind class merge
vault/wiki/skills/design/SKILL.md — frontend craft, styling, typography, motion, and shadcn policy for UI surfaces.
apps/web/plugins/session-journal/ — infrastructure, DO NOT edit. Vite dev plugin injects the browser session journal client; events go over HMR (`import.meta.hot.send('session-journal:event', …)`); the plugin arranges persistence under `vault/temp/SESSION_JOURNAL.md`.
Routes: / → HomePage, /blog → BlogPage, /blog/:slug → ArticlePage
