import {
  Leaf, Ruler, Map, ShieldCheck, Plane, Crosshair, Lightbulb, Recycle, Gauge,
} from 'lucide-react';

export const IMAGES = {
  hero: 'https://images.hostinger.com/ec9356b9-9e77-4ade-a067-8b0ca6f2c3a0.png',
  about: 'https://images.hostinger.com/8a4ce4c2-ffe2-4c04-ad64-e55b2f106f3b.png',
  drone: 'https://images.hostinger.com/bbbea0e8-c36d-442c-b9de-8ebec5c869a3.png',
  station: 'https://images.hostinger.com/f985e70e-c9f6-4858-a765-910e79146131.png',
  gis: 'https://images.hostinger.com/00a0f03d-714d-4744-991d-954c688659ba.png',
  water: 'https://images.hostinger.com/2d13feea-0f8c-459e-8592-53940c721f2d.png',
  pointcloud: 'https://images.hostinger.com/514c1ae6-5dd6-4ab3-8638-c4cfb835bdec.png',
  highway: 'https://images.hostinger.com/1dbfd035-b1bd-4327-98dc-c2afdcde432c.png',
};

export const NAV = [
  { id: 'inicio', label: 'Inicio' },
  { id: 'servicios', label: 'Servicios' },
  { id: 'nosotros', label: 'Nosotros' },
  { id: 'diferenciadores', label: 'Por qué elegirnos' },
  { id: 'blog', label: 'Blog' },
  { id: 'contacto', label: 'Contacto' },
];

export const SERVICES = [
  {
    id: 'ambiental',
    icon: Leaf,
    title: 'Consultoría Ambiental',
    image: IMAGES.water,
    description:
      'Acompañamos proyectos de infraestructura con estudios y estrategias que garantizan el cumplimiento normativo y la sostenibilidad del territorio.',
    items: [
      'Estudios de impacto ambiental (EIA)',
      'Licenciamiento ante ANLA y autoridades regionales',
      'Planes de manejo y compensación ambiental',
      'Monitoreo de calidad de agua, aire y suelo',
    ],
  },
  {
    id: 'ingenieria',
    icon: Ruler,
    title: 'Ingeniería y Topografía',
    image: IMAGES.station,
    description:
      'Levantamientos de alta precisión y geodesia que sustentan el diseño y la construcción de obras civiles, viales y energéticas.',
    items: [
      'Levantamientos topográficos y batimétricos',
      'Redes geodésicas y georreferenciación GNSS',
      'Replanteo y control de obra',
      'Modelos digitales de terreno (MDT)',
    ],
  },
  {
    id: 'gis',
    icon: Map,
    title: 'SIG y Cartografía',
    image: IMAGES.gis,
    description:
      'Convertimos datos geoespaciales en información estratégica mediante SIG, teledetección y captura con tecnología LiDAR y UAV.',
    items: [
      'Cartografía temática y catastral',
      'Adquisición y procesamiento LiDAR / fotogrametría UAV',
      'Análisis espacial y bases de datos geográficas',
      'Visores web y dashboards geoespaciales',
    ],
  },
];

export const DIFFERENTIATORS = [
  { icon: ShieldCheck, title: 'Cumplimiento ANLA e IGAC', text: 'Procesos alineados a la normativa ambiental y cartográfica nacional para blindar cada proyecto.' },
  { icon: Plane, title: 'Tecnología LiDAR y UAV', text: 'Captura aérea de nube de puntos de alta densidad con drones de última generación.' },
  { icon: Crosshair, title: 'Topografía de alta precisión', text: 'Equipos GNSS y estaciones totales calibradas con precisión milimétrica certificable.' },
  { icon: Lightbulb, title: 'Consultoría estratégica', text: 'Acompañamiento técnico que traduce datos en decisiones sólidas para su inversión.' },
  { icon: Recycle, title: 'Sostenibilidad', text: 'Soluciones que equilibran el desarrollo con la protección de los ecosistemas.' },
  { icon: Gauge, title: 'Eficiencia operativa', text: 'Flujos de trabajo optimizados que reducen tiempos y costos sin sacrificar calidad.' },
];

export const STATS = [
  { value: '15+', label: 'Años de experiencia' },
  { value: '320+', label: 'Proyectos entregados' },
  { value: '98%', label: 'Precisión certificada' },
  { value: '24', label: 'Departamentos atendidos' },
];

export const CATEGORIES = ['Todos', 'Ambiental', 'Geomática', 'Tecnología', 'Normativa'];

export const POSTS = [
  {
    slug: 'lidar-cambia-topografia',
    title: 'Cómo la tecnología LiDAR está transformando la topografía moderna',
    category: 'Tecnología',
    date: '2024-05-12',
    readTime: '6 min',
    image: IMAGES.pointcloud,
    excerpt: 'La captura de nube de puntos con LiDAR permite modelar el terreno con un nivel de detalle inédito y reducir el trabajo de campo.',
    content: [
      'La tecnología LiDAR (Light Detection and Ranging) ha redefinido la forma en que capturamos la realidad del territorio. Mediante pulsos láser emitidos desde plataformas aéreas o terrestres, es posible generar millones de puntos que reconstruyen la superficie con precisión centimétrica.',
      'En TOPOSIG integramos LiDAR aerotransportado en drones UAV para proyectos de infraestructura vial, minería y gestión de riesgo. Esto reduce drásticamente los tiempos de levantamiento y minimiza la exposición del personal en zonas de difícil acceso.',
      'El resultado son modelos digitales de terreno y superficie que alimentan directamente los flujos de diseño de ingeniería, permitiendo decisiones más rápidas y confiables.',
    ],
  },
  {
    slug: 'licenciamiento-anla-guia',
    title: 'Licenciamiento ambiental ante la ANLA: guía práctica para proyectos',
    category: 'Normativa',
    date: '2024-04-02',
    readTime: '8 min',
    image: IMAGES.water,
    excerpt: 'Entender los tiempos y requisitos del licenciamiento ambiental es clave para la viabilidad de cualquier obra en Colombia.',
    content: [
      'El licenciamiento ambiental es un requisito esencial para proyectos que puedan generar afectaciones significativas al medio ambiente. La Autoridad Nacional de Licencias Ambientales (ANLA) establece los procedimientos y estándares que deben cumplirse.',
      'Un estudio de impacto ambiental riguroso, con línea base sólida y planes de manejo bien estructurados, es la mejor herramienta para agilizar la aprobación y evitar reprocesos.',
      'Nuestro equipo acompaña a los titulares en cada etapa, desde el diagnóstico hasta el seguimiento de los compromisos adquiridos.',
    ],
  },
  {
    slug: 'gis-decisiones-territoriales',
    title: 'SIG: convirtiendo datos geoespaciales en decisiones territoriales',
    category: 'Geomática',
    date: '2024-03-18',
    readTime: '5 min',
    image: IMAGES.gis,
    excerpt: 'Los Sistemas de Información Geográfica permiten analizar patrones espaciales y planificar el territorio con evidencia.',
    content: [
      'Un Sistema de Información Geográfica (SIG) organiza, analiza y visualiza datos con componente espacial. Su potencia radica en revelar relaciones que no son evidentes en tablas o mapas estáticos.',
      'Desde catastro multipropósito hasta análisis de riesgo, el SIG se ha convertido en la columna vertebral de la planificación territorial moderna.',
      'Diseñamos visores web y dashboards que ponen la información al alcance de tomadores de decisión, en tiempo real y desde cualquier dispositivo.',
    ],
  },
  {
    slug: 'drones-uav-medio-ambiente',
    title: 'Drones UAV al servicio del monitoreo ambiental',
    category: 'Ambiental',
    date: '2024-02-27',
    readTime: '4 min',
    image: IMAGES.drone,
    excerpt: 'La fotogrametría con drones facilita el seguimiento de coberturas vegetales, cuerpos de agua y áreas de compensación.',
    content: [
      'Los vehículos aéreos no tripulados (UAV) permiten monitorear grandes extensiones de forma periódica y económica.',
      'Con sensores multiespectrales evaluamos el estado de la vegetación y detectamos cambios en las coberturas a lo largo del tiempo.',
      'Esta información es fundamental para verificar el cumplimiento de compromisos ambientales y la efectividad de las medidas de compensación.',
    ],
  },
  {
    slug: 'geodesia-precision-obra',
    title: 'Geodesia de precisión: la base invisible de toda gran obra',
    category: 'Geomática',
    date: '2024-01-15',
    readTime: '5 min',
    image: IMAGES.station,
    excerpt: 'Las redes geodésicas garantizan que cada medición del proyecto esté referida a un marco confiable y coherente.',
    content: [
      'La geodesia establece el marco de referencia sobre el cual se apoyan todas las mediciones de un proyecto.',
      'El uso de tecnología GNSS de doble frecuencia y post-proceso asegura coordenadas robustas incluso en zonas remotas.',
      'Sin una base geodésica sólida, los errores se propagan y comprometen la integridad de toda la obra.',
    ],
  },
  {
    slug: 'infraestructura-vial-sostenible',
    title: 'Infraestructura vial sostenible: ingeniería y ambiente en equilibrio',
    category: 'Ambiental',
    date: '2023-12-05',
    readTime: '7 min',
    image: IMAGES.highway,
    excerpt: 'Diseñar corredores viales sostenibles exige integrar la ingeniería con criterios ambientales desde la etapa temprana.',
    content: [
      'La infraestructura vial conecta territorios, pero su desarrollo debe minimizar la fragmentación de ecosistemas.',
      'Integrar los estudios ambientales y topográficos desde las fases iniciales reduce sobrecostos y conflictos posteriores.',
      'Apostamos por corredores que respeten la conectividad ecológica y el bienestar de las comunidades.',
    ],
  },
];

export const CONTACT = {
  phone: '+57 300 123 4567',
  whatsapp: '573001234567',
  email: 'contacto@toposig.com.co',
  address: 'Calle 100 # 8A-55, Bogotá D.C., Colombia',
  hours: 'Lun – Vie: 8:00 a.m. – 6:00 p.m.',
};
