import { Target, Eye, Award } from 'lucide-react';
import { IMAGES } from '@/data/site';
import Reveal from '@/components/Reveal';

const CARDS = [
  { icon: Target, title: 'Misión', text: 'Entregar soluciones geoespaciales y ambientales de alta precisión que impulsen un desarrollo responsable y sostenible en Colombia.' },
  { icon: Eye, title: 'Visión', text: 'Ser la firma de referencia nacional en geomática, consultoría ambiental e ingeniería de precisión para 2030.' },
  { icon: Award, title: 'Política de calidad', text: 'Mejora continua, cumplimiento normativo y estándares internacionales en cada levantamiento y estudio que realizamos.' },
];

const About = () => (
  <section id="nosotros" className="py-24">
    <div className="container-wide grid items-center gap-12 lg:grid-cols-2">
      <Reveal>
        <div className="relative">
          <img
            src={IMAGES.about}
            alt="Equipo profesional de TOPOSIG analizando datos topográficos y mapas SIG en su oficina de Bogotá"
            loading="lazy"
            className="w-full rounded-[2rem] object-cover shadow-[0_40px_90px_-45px_rgba(10,37,64,0.5)]"
          />
          <div className="absolute -bottom-6 -right-4 hidden rounded-2xl bg-white p-5 shadow-xl sm:block">
            <p className="font-[Montserrat] text-3xl font-extrabold text-emerald-600">ISO</p>
            <p className="text-sm text-muted-foreground">Procesos certificables</p>
          </div>
        </div>
      </Reveal>

      <div>
        <Reveal>
          <p className="text-sm font-semibold uppercase tracking-widest text-emerald-600">Nosotros</p>
          <h2 className="mt-3 text-3xl font-extrabold sm:text-4xl">Ingeniería, ambiente y datos al servicio del territorio</h2>
          <p className="mt-4 leading-relaxed text-muted-foreground">
            TOPOSIG S.A.S. nace de la convicción de que las mejores decisiones de infraestructura se toman con
            información precisa y responsable. Combinamos experiencia en campo con tecnología de vanguardia para
            entregar resultados confiables en cada proyecto.
          </p>
        </Reveal>

        <div className="mt-8 space-y-4">
          {CARDS.map((c, i) => {
            const Icon = c.icon;
            return (
              <Reveal key={c.title} delay={i * 0.08}>
                <div className="glass-card flex gap-4 p-5 transition-transform hover:-translate-y-1">
                  <span className="grid h-12 w-12 shrink-0 place-items-center rounded-2xl bg-gradient-to-br from-emerald-500 to-blue-500 text-white">
                    <Icon className="h-6 w-6" />
                  </span>
                  <div>
                    <h3 className="text-lg font-bold">{c.title}</h3>
                    <p className="mt-1 text-sm leading-relaxed text-muted-foreground">{c.text}</p>
                  </div>
                </div>
              </Reveal>
            );
          })}
        </div>
      </div>
    </div>
  </section>
);

export default About;
