import { useState } from 'react';
import { Phone, Mail, MapPin, Clock, MessageCircle, Send, CheckCircle2, Loader2 } from 'lucide-react';
import { CONTACT } from '@/data/site';
import Reveal from '@/components/Reveal';

const INFO = [
  { icon: Phone, label: 'Teléfono', value: CONTACT.phone, href: `tel:${CONTACT.phone.replace(/\s/g, '')}` },
  { icon: Mail, label: 'Correo', value: CONTACT.email, href: `mailto:${CONTACT.email}` },
  { icon: MapPin, label: 'Oficina', value: CONTACT.address },
  { icon: Clock, label: 'Horario', value: CONTACT.hours },
];

const Contact = () => {
  const [form, setForm] = useState({ name: '', email: '', phone: '', message: '' });
  const [errors, setErrors] = useState({});
  const [status, setStatus] = useState('idle');

  const set = (k) => (e) => { setForm((f) => ({ ...f, [k]: e.target.value })); setErrors((x) => ({ ...x, [k]: '' })); };

  const validate = () => {
    const e = {};
    if (!form.name.trim()) e.name = 'Ingrese su nombre';
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) e.email = 'Correo no válido';
    if (form.message.trim().length < 10) e.message = 'Cuéntenos un poco más (mín. 10 caracteres)';
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const submit = (ev) => {
    ev.preventDefault();
    if (!validate()) return;
    setStatus('loading');
    setTimeout(() => {
      setStatus('done');
      setForm({ name: '', email: '', phone: '', message: '' });
    }, 1100);
  };

  const inputCls = (k) =>
    `w-full rounded-xl border bg-white px-4 py-3 text-sm outline-none transition focus:ring-2 focus:ring-emerald-400/30 ${
      errors[k] ? 'border-destructive' : 'border-border focus:border-emerald-400'
    }`;

  return (
    <section id="contacto" className="py-24">
      <div className="container-wide grid gap-10 lg:grid-cols-2">
        <Reveal>
          <p className="text-sm font-semibold uppercase tracking-widest text-emerald-600">Contacto</p>
          <h2 className="mt-3 text-3xl font-extrabold sm:text-4xl">Hablemos de su próximo proyecto</h2>
          <p className="mt-4 leading-relaxed text-muted-foreground">
            Nuestro equipo técnico está listo para asesorarle. Escríbanos y le responderemos a la brevedad.
          </p>

          <div className="mt-8 grid gap-4 sm:grid-cols-2">
            {INFO.map((it) => {
              const Icon = it.icon;
              const inner = (
                <div className="glass-card flex items-start gap-3 p-4 transition-transform hover:-translate-y-1">
                  <span className="grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-emerald-100 text-emerald-600">
                    <Icon className="h-5 w-5" />
                  </span>
                  <div className="min-w-0">
                    <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">{it.label}</p>
                    <p className="mt-0.5 break-words text-sm font-medium text-foreground">{it.value}</p>
                  </div>
                </div>
              );
              return it.href ? <a key={it.label} href={it.href}>{inner}</a> : <div key={it.label}>{inner}</div>;
            })}
          </div>

          <a
            href={`https://wa.me/${CONTACT.whatsapp}`}
            target="_blank" rel="noreferrer"
            className="mt-6 inline-flex items-center gap-2 rounded-full bg-emerald-500 px-6 py-3 text-sm font-semibold text-white shadow-lg shadow-emerald-500/25 transition-transform hover:-translate-y-0.5"
          >
            <MessageCircle className="h-5 w-5" /> Escríbenos por WhatsApp
          </a>
        </Reveal>

        <Reveal delay={0.1}>
          <form onSubmit={submit} noValidate className="rounded-[2rem] bg-white p-6 shadow-[0_30px_80px_-40px_rgba(10,37,64,0.4)] sm:p-8">
            {status === 'done' ? (
              <div className="flex flex-col items-center justify-center py-16 text-center">
                <CheckCircle2 className="h-14 w-14 text-emerald-500" />
                <h3 className="mt-4 text-xl font-bold">¡Mensaje enviado!</h3>
                <p className="mt-2 text-sm text-muted-foreground">Gracias por escribirnos. Le contactaremos muy pronto.</p>
                <button type="button" onClick={() => setStatus('idle')} className="mt-6 text-sm font-semibold text-emerald-600">
                  Enviar otro mensaje
                </button>
              </div>
            ) : (
              <div className="space-y-5">
                <div className="flex flex-col gap-2">
                  <label htmlFor="name" className="text-sm font-medium">Nombre completo</label>
                  <input id="name" value={form.name} onChange={set('name')} className={inputCls('name')} aria-invalid={!!errors.name} />
                  {errors.name && <span className="text-xs text-destructive">{errors.name}</span>}
                </div>
                <div className="grid gap-5 sm:grid-cols-2">
                  <div className="flex flex-col gap-2">
                    <label htmlFor="email" className="text-sm font-medium">Correo electrónico</label>
                    <input id="email" type="email" value={form.email} onChange={set('email')} className={inputCls('email')} aria-invalid={!!errors.email} />
                    {errors.email && <span className="text-xs text-destructive">{errors.email}</span>}
                  </div>
                  <div className="flex flex-col gap-2">
                    <label htmlFor="phone" className="text-sm font-medium">Teléfono <span className="text-muted-foreground">(opcional)</span></label>
                    <input id="phone" value={form.phone} onChange={set('phone')} className={inputCls('phone')} />
                  </div>
                </div>
                <div className="flex flex-col gap-2">
                  <label htmlFor="message" className="text-sm font-medium">Mensaje</label>
                  <textarea id="message" rows={5} value={form.message} onChange={set('message')} className={`${inputCls('message')} resize-none`} aria-invalid={!!errors.message} />
                  {errors.message && <span className="text-xs text-destructive">{errors.message}</span>}
                </div>
                <button
                  type="submit"
                  disabled={status === 'loading'}
                  className="inline-flex w-full items-center justify-center gap-2 rounded-full bg-gradient-to-r from-emerald-500 to-blue-500 px-6 py-3.5 text-sm font-semibold text-white shadow-lg shadow-emerald-500/25 transition-transform hover:-translate-y-0.5 active:scale-[0.99] disabled:opacity-70"
                >
                  {status === 'loading' ? <><Loader2 className="h-5 w-5 animate-spin" /> Enviando...</> : <><Send className="h-5 w-5" /> Enviar mensaje</>}
                </button>
              </div>
            )}
          </form>
        </Reveal>
      </div>
    </section>
  );
};

export default Contact;
