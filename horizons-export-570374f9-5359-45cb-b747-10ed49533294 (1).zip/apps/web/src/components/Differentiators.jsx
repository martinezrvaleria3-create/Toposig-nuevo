import { DIFFERENTIATORS } from '@/data/site';
import Reveal from '@/components/Reveal';

const Differentiators = () => (
  <section id="diferenciadores" className="relative overflow-hidden bg-[#04231b] py-24 text-white">
    <div className="pointer-events-none absolute -left-40 top-0 h-96 w-96 rounded-full bg-emerald-500/20 blur-3xl" />
    <div className="pointer-events-none absolute -right-40 bottom-0 h-96 w-96 rounded-full bg-blue-500/20 blur-3xl" />
    <div className="container-wide relative">
      <Reveal className="mx-auto max-w-2xl text-center">
        <p className="text-sm font-semibold uppercase tracking-widest text-emerald-300">Por qué elegirnos</p>
        <h2 className="mt-3 text-3xl font-extrabold sm:text-4xl">Razones para confiar en TOPOSIG</h2>
        <p className="mt-4 text-white/70">Tecnología, rigor técnico y compromiso ambiental en cada entrega.</p>
      </Reveal>

      <div className="mt-14 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
        {DIFFERENTIATORS.map((d, i) => {
          const Icon = d.icon;
          return (
            <Reveal key={d.title} delay={(i % 3) * 0.08}>
              <div className="group h-full rounded-3xl border border-white/10 bg-white/5 p-7 backdrop-blur-md transition-all hover:-translate-y-1.5 hover:border-emerald-400/40 hover:bg-white/10">
                <span className="grid h-14 w-14 place-items-center rounded-2xl bg-gradient-to-br from-emerald-500 to-blue-500 text-white shadow-lg shadow-emerald-500/30">
                  <Icon className="h-7 w-7" />
                </span>
                <h3 className="mt-5 text-xl font-bold">{d.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-white/70">{d.text}</p>
              </div>
            </Reveal>
          );
        })}
      </div>
    </div>
  </section>
);

export default Differentiators;
