import { useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { Search, ArrowRight, Calendar, Clock } from 'lucide-react';
import { POSTS, CATEGORIES } from '@/data/site';
import Reveal from '@/components/Reveal';

const PAGE_SIZE = 3;

export const formatDate = (iso) =>
  new Date(iso).toLocaleDateString('es-CO', { day: '2-digit', month: 'short', year: 'numeric' });

const BlogSection = () => {
  const [query, setQuery] = useState('');
  const [cat, setCat] = useState('Todos');
  const [page, setPage] = useState(1);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return POSTS.filter((p) => {
      const matchCat = cat === 'Todos' || p.category === cat;
      const matchQ = !q || p.title.toLowerCase().includes(q) || p.excerpt.toLowerCase().includes(q);
      return matchCat && matchQ;
    });
  }, [query, cat]);

  const totalPages = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE));
  const safePage = Math.min(page, totalPages);
  const visible = filtered.slice((safePage - 1) * PAGE_SIZE, safePage * PAGE_SIZE);

  const reset = (fn) => { fn(); setPage(1); };

  return (
    <section id="blog" className="bg-muted/40 py-24">
      <div className="container-wide">
        <Reveal className="mx-auto max-w-2xl text-center">
          <p className="text-sm font-semibold uppercase tracking-widest text-emerald-600">Blog</p>
          <h2 className="mt-3 text-3xl font-extrabold sm:text-4xl">Conocimiento geoespacial y ambiental</h2>
          <p className="mt-4 text-muted-foreground">Artículos, tendencias y buenas prácticas de nuestro equipo técnico.</p>
        </Reveal>

        <div className="mx-auto mt-10 flex max-w-3xl flex-col items-center gap-4 sm:flex-row">
          <div className="relative w-full">
            <Search className="pointer-events-none absolute left-4 top-1/2 h-5 w-5 -translate-y-1/2 text-muted-foreground" />
            <input
              type="search"
              value={query}
              onChange={(e) => reset(() => setQuery(e.target.value))}
              placeholder="Buscar artículos..."
              aria-label="Buscar artículos"
              className="w-full rounded-full border border-border bg-white py-3 pl-12 pr-4 text-sm outline-none transition focus:border-emerald-400 focus:ring-2 focus:ring-emerald-400/30"
            />
          </div>
        </div>

        <div className="mt-6 flex flex-wrap justify-center gap-2">
          {CATEGORIES.map((c) => (
            <button
              key={c}
              onClick={() => reset(() => setCat(c))}
              className={`rounded-full px-4 py-1.5 text-sm font-medium transition ${
                cat === c ? 'bg-emerald-500 text-white' : 'bg-white text-foreground/70 hover:text-emerald-600'
              }`}
            >
              {c}
            </button>
          ))}
        </div>

        {visible.length === 0 ? (
          <p className="mt-16 text-center text-muted-foreground">No se encontraron artículos que coincidan con su búsqueda.</p>
        ) : (
          <div className="mt-12 grid gap-8 md:grid-cols-2 lg:grid-cols-3">
            {visible.map((p, i) => (
              <Reveal key={p.slug} delay={(i % 3) * 0.08}>
                <article className="group flex h-full flex-col overflow-hidden rounded-3xl bg-white shadow-[0_20px_60px_-35px_rgba(10,37,64,0.4)] transition-transform hover:-translate-y-1.5">
                  <Link to={`/blog/${p.slug}`} className="block overflow-hidden">
                    <img
                      src={p.image}
                      alt={`Imagen del artículo: ${p.title}`}
                      loading="lazy"
                      className="h-52 w-full object-cover transition-transform duration-700 group-hover:scale-105"
                    />
                  </Link>
                  <div className="flex flex-1 flex-col p-6">
                    <span className="w-fit rounded-full bg-emerald-100 px-3 py-1 text-xs font-semibold text-emerald-700">{p.category}</span>
                    <h3 className="mt-3 text-lg font-bold leading-snug">
                      <Link to={`/blog/${p.slug}`} className="transition-colors hover:text-emerald-600">{p.title}</Link>
                    </h3>
                    <p className="mt-2 flex-1 text-sm leading-relaxed text-muted-foreground">{p.excerpt}</p>
                    <div className="mt-4 flex items-center gap-4 text-xs text-muted-foreground">
                      <span className="inline-flex items-center gap-1"><Calendar className="h-3.5 w-3.5" />{formatDate(p.date)}</span>
                      <span className="inline-flex items-center gap-1"><Clock className="h-3.5 w-3.5" />{p.readTime}</span>
                    </div>
                    <Link to={`/blog/${p.slug}`} className="mt-4 inline-flex items-center gap-1.5 text-sm font-semibold text-emerald-600">
                      Leer más <ArrowRight className="h-4 w-4" />
                    </Link>
                  </div>
                </article>
              </Reveal>
            ))}
          </div>
        )}

        {totalPages > 1 && (
          <div className="mt-12 flex justify-center gap-2">
            {Array.from({ length: totalPages }).map((_, i) => (
              <button
                key={i}
                onClick={() => setPage(i + 1)}
                aria-label={`Página ${i + 1}`}
                aria-current={safePage === i + 1 ? 'page' : undefined}
                className={`h-10 w-10 rounded-full text-sm font-semibold transition ${
                  safePage === i + 1 ? 'bg-gradient-to-r from-emerald-500 to-blue-500 text-white' : 'bg-white text-foreground/70 hover:text-emerald-600'
                }`}
              >
                {i + 1}
              </button>
            ))}
          </div>
        )}
      </div>
    </section>
  );
};

export default BlogSection;
