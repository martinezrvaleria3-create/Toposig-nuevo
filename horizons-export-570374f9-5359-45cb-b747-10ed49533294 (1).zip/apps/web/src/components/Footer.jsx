import { useNavigate, useLocation } from 'react-router-dom';
import { Linkedin, Facebook, Instagram, Lock } from 'lucide-react';
import { NAV, CONTACT } from '@/data/site';
import Logo from '@/components/Logo';

const Footer = () => {
  const navigate = useNavigate();
  const location = useLocation();

  const go = (id) => {
    if (location.pathname !== '/') {
      navigate('/');
      setTimeout(() => document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' }), 120);
    } else {
      document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <footer className="bg-[#04231b] text-white/80">
      <div className="container-wide grid gap-10 py-16 md:grid-cols-4">
        <div className="md:col-span-1">
          <Logo light />
          <p className="mt-4 max-w-xs text-sm leading-relaxed text-white/60">
            Consultoría ambiental, geomática e ingeniería de precisión para el desarrollo sostenible de Colombia.
          </p>
          <div className="mt-5 flex gap-3">
            {[Linkedin, Facebook, Instagram].map((Icon, i) => (
              <a key={i} href="#" aria-label="Red social" className="grid h-10 w-10 place-items-center rounded-full bg-white/10 transition hover:bg-emerald-500">
                <Icon className="h-5 w-5" />
              </a>
            ))}
          </div>
        </div>

        <div>
          <h3 className="text-sm font-bold uppercase tracking-wide text-white">Navegación</h3>
          <ul className="mt-4 space-y-2.5 text-sm">
            {NAV.map((n) => (
              <li key={n.id}>
                <button onClick={() => go(n.id)} className="transition hover:text-emerald-400">{n.label}</button>
              </li>
            ))}
          </ul>
        </div>

        <div>
          <h3 className="text-sm font-bold uppercase tracking-wide text-white">Contacto</h3>
          <ul className="mt-4 space-y-2.5 text-sm text-white/60">
            <li>{CONTACT.phone}</li>
            <li className="break-words">{CONTACT.email}</li>
            <li>{CONTACT.address}</li>
            <li>{CONTACT.hours}</li>
          </ul>
        </div>

        <div>
          <h3 className="text-sm font-bold uppercase tracking-wide text-white">Acceso</h3>
          <a href="#" className="mt-4 inline-flex items-center gap-2 rounded-full border border-white/20 px-4 py-2 text-sm transition hover:border-emerald-400 hover:text-emerald-400">
            <Lock className="h-4 w-4" /> Portal corporativo
          </a>
        </div>
      </div>

      <div className="border-t border-white/10">
        <div className="container-wide flex flex-col items-center justify-between gap-2 py-6 text-xs text-white/50 sm:flex-row">
          <p>© {new Date().getFullYear()} TOPOSIG S.A.S. Todos los derechos reservados.</p>
          <p>Bogotá D.C., Colombia</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
