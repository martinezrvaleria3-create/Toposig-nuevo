import { Helmet } from 'react-helmet';
import { IMAGES } from '@/data/site';

const Seo = ({
  title = 'TOPOSIG S.A.S. | Consultoría ambiental, geomática e ingeniería de precisión',
  description = 'TOPOSIG S.A.S. integra consultoría ambiental, geomática, LiDAR, SIG, geodesia y topografía de alta precisión para proyectos de infraestructura sostenibles en Colombia.',
  image = IMAGES.hero,
  type = 'website',
  jsonLd,
}) => (
  <Helmet>
    <title>{title}</title>
    <meta name="description" content={description} />
    <meta property="og:type" content={type} />
    <meta property="og:title" content={title} />
    <meta property="og:description" content={description} />
    <meta property="og:image" content={image} />
    <meta name="twitter:card" content="summary_large_image" />
    <meta name="twitter:title" content={title} />
    <meta name="twitter:description" content={description} />
    {jsonLd && <script type="application/ld+json">{JSON.stringify(jsonLd)}</script>}
  </Helmet>
);

export default Seo;
