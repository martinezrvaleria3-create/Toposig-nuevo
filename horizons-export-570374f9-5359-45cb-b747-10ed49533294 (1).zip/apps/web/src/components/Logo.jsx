const Logo = ({ light = false }) => (
  <div className="flex items-center gap-2.5">
    <span className="grid h-10 w-10 place-items-center rounded-xl bg-gradient-to-br from-emerald-500 to-blue-500 shadow-lg shadow-emerald-500/30">
      <svg width="22" height="22" viewBox="0 0 24 24" fill="none" aria-hidden="true">
        <path d="M12 2 3 7v10l9 5 9-5V7l-9-5Z" stroke="white" strokeWidth="1.6" strokeLinejoin="round" />
        <path d="M3 7l9 5 9-5M12 12v10" stroke="white" strokeWidth="1.6" strokeLinejoin="round" />
      </svg>
    </span>
    <span className={`font-[Montserrat] text-xl font-extrabold tracking-tight ${light ? 'text-white' : 'text-foreground'}`}>
      TOPO<span className="text-emerald-500">SIG</span>
    </span>
  </div>
);

export default Logo;
