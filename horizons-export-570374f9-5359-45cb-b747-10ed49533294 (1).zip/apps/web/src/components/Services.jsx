import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Check } from 'lucide-react';
import { SERVICES } from '@/data/site';
import Reveal from '@/components/Reveal';

const Services = () => {
  const [active, setActive] = useState(SERVICES[0].id);
  const current = SERVICES.find((s) => s.id === active);

  return (
    <section id="servicios" className="relative bg-muted/40 py-24">
      <div className="container-wide">
        <Reveal className="mx-auto max-w-2xl text-center">
          <p className="text-sm font-semibold uppercase tracking-widest text-emerald-600">Servicios</p>
          <h2 className="mt-3 text-3xl font-extrabold sm:text-4xl">Soluciones integrales en geomática y ambiente</h2>
          <p className="mt-4 text-muted-foreground">
            Un mismo aliado para cada etapa de su proyecto, desde el diagnóstico ambiental hasta la entrega de datos geoespaciales listos para decidir.
          </p>
        </Reveal>

        <div className="mt-10 flex flex-wrap justify-center gap-3" role="tablist" aria-label="Servicios">
          {SERVICES.map((s) => {
            const Icon = s.icon;
            const on = s.id === active;
            return (
              <button
                key={s.id}
                role="tab"
                aria-selected={on}
                onClick={() => setActive(s.id)}
                className={`inline-flex items-center gap-2 rounded-full px-5 py-3 text-sm font-semibold transition ${
                  on
                    ? 'bg-gradient-to-r from-emerald-500 to-blue-500 text-white shadow-lg shadow-emerald-500/25'
                    : 'bg-white text-foreground/70 shadow-sm hover:text-emerald-600'
                }`}
              >
                <Icon className="h-4 w-4" strokeWidth={2} /> {s.title}
              </button>
            );
          })}
        </div>

        <AnimatePresence mode="wait">
          <motion.div
            key={active}
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            transition={{ duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
            className="mt-10 grid items-center gap-8 rounded-[2rem] bg-white p-6 shadow-[0_30px_80px_-40px_rgba(16,185,129,0.35)] md:grid-cols-2 md:p-10"
          >
            <div>
              <h3 className="text-2xl font-bold text-foreground">{current.title}</h3>
              <p className="mt-3 leading-relaxed text-muted-foreground">{current.description}</p>
              <ul className="mt-6 space-y-3">
                {current.items.map((item) => (
                  <li key={item} className="flex items-start gap-3">
                    <span className="mt-0.5 grid h-6 w-6 shrink-0 place-items-center rounded-full bg-emerald-100 text-emerald-600">
                      <Check className="h-4 w-4" />
                    </span>
                    <span className="text-foreground/85">{item}</span>
                  </li>
                ))}
              </ul>
            </div>
            <div className="overflow-hidden rounded-3xl">
              <img
                src={current.image}
                alt={`Ilustración del servicio ${current.title}`}
                loading="lazy"
                className="h-72 w-full object-cover transition-transform duration-700 hover:scale-105 md:h-80"
              />
            </div>
          </motion.div>
        </AnimatePresence>
      </div>
    </section>
  );
};

export default Services;
