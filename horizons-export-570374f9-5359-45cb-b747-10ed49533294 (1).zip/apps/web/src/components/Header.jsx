import { useEffect, useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { Menu, X, MessageCircle } from 'lucide-react';
import { NAV, CONTACT } from '@/data/site';
import Logo from '@/components/Logo';

const Header = () => {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  const [active, setActive] = useState('inicio');
  const navigate = useNavigate();
  const location = useLocation();

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40);
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  useEffect(() => {
    if (location.pathname !== '/') return undefined;
    const sections = NAV.map((n) => document.getElementById(n.id)).filter(Boolean);
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((e) => { if (e.isIntersecting) setActive(e.target.id); });
      },
      { rootMargin: '-45% 0px -50% 0px' }
    );
    sections.forEach((s) => observer.observe(s));
    return () => observer.disconnect();
  }, [location.pathname]);

  const go = (id) => {
    setOpen(false);
    if (location.pathname !== '/') {
      navigate('/');
      setTimeout(() => document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' }), 120);
    } else {
      document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const onHome = location.pathname === '/';
  const solid = scrolled || open || !onHome;

  return (
    <header
      className={`fixed inset-x-0 top-0 z-50 transition-all duration-300 ${
        solid ? 'bg-white/80 backdrop-blur-xl shadow-[0_8px_30px_-15px_rgba(16,185,129,0.25)]' : 'bg-transparent'
      }`}
    >
      <nav className="container-wide flex h-[76px] items-center justify-between" aria-label="Principal">
        <button onClick={() => go('inicio')} aria-label="Ir al inicio" className="shrink-0">
          <Logo />
        </button>

        <ul className="hidden items-center gap-1 lg:flex">
          {NAV.map((n) => (
            <li key={n.id}>
              <button
                onClick={() => go(n.id)}
                className={`rounded-full px-4 py-2 text-sm font-medium transition-colors ${
                  onHome && active === n.id
                    ? 'text-emerald-600'
                    : 'text-foreground/70 hover:text-emerald-600'
                }`}
                aria-current={onHome && active === n.id ? 'true' : undefined}
              >
                {n.label}
              </button>
            </li>
          ))}
        </ul>

        <div className="hidden items-center gap-3 lg:flex">
          <a
            href={`https://wa.me/${CONTACT.whatsapp}`}
            target="_blank" rel="noreferrer"
            className="grid h-10 w-10 place-items-center rounded-full text-emerald-600 transition hover:bg-emerald-50"
            aria-label="WhatsApp"
          >
            <MessageCircle className="h-5 w-5" />
          </a>
          <button
            onClick={() => go('contacto')}
            className="rounded-full bg-gradient-to-r from-emerald-500 to-blue-500 px-5 py-2.5 text-sm font-semibold text-white shadow-lg shadow-emerald-500/25 transition-transform hover:-translate-y-0.5 active:scale-[0.98]"
          >
            Contáctenos
          </button>
        </div>

        <button
          className="grid h-11 w-11 place-items-center rounded-xl text-foreground lg:hidden"
          onClick={() => setOpen((v) => !v)}
          aria-label={open ? 'Cerrar menú' : 'Abrir menú'}
          aria-expanded={open}
        >
          {open ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
        </button>
      </nav>

      {open && (
        <div className="border-t border-border bg-white/95 backdrop-blur-xl lg:hidden">
          <ul className="container-wide flex flex-col py-3">
            {NAV.map((n) => (
              <li key={n.id}>
                <button
                  onClick={() => go(n.id)}
                  className="w-full rounded-xl px-3 py-3 text-left text-base font-medium text-foreground/80 hover:bg-emerald-50 hover:text-emerald-600"
                >
                  {n.label}
                </button>
              </li>
            ))}
            <li className="px-1 pt-2">
              <button
                onClick={() => go('contacto')}
                className="w-full rounded-full bg-gradient-to-r from-emerald-500 to-blue-500 px-5 py-3 text-center text-sm font-semibold text-white"
              >
                Contáctenos
              </button>
            </li>
          </ul>
        </div>
      )}
    </header>
  );
};

export default Header;
