import { motion } from 'framer-motion';
import { ArrowRight, PlayCircle } from 'lucide-react';
import { IMAGES, STATS } from '@/data/site';

const scrollTo = (id) => document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' });

const Hero = () => (
  <section id="inicio" className="relative flex min-h-[100dvh] items-center overflow-hidden">
    <div className="absolute inset-0">
      <img
        src={IMAGES.hero}
        alt="Equipo de topografía operando tecnología LiDAR en un valle andino de Colombia"
        className="h-full w-full object-cover"
        fetchPriority="high"
      />
      <div className="absolute inset-0 bg-gradient-to-r from-[#04231b]/90 via-[#04231b]/70 to-[#0a2540]/40" />
      <div className="absolute inset-0 bg-gradient-to-t from-[#04231b]/80 via-transparent to-transparent" />
    </div>

    <div className="container-wide relative z-10 pt-28 pb-16">
      <motion.span
        initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }}
        className="inline-flex items-center gap-2 rounded-full border border-emerald-400/40 bg-emerald-400/10 px-4 py-1.5 text-sm font-medium text-emerald-200 backdrop-blur"
      >
        <span className="h-2 w-2 rounded-full bg-emerald-400" /> Consultoría ambiental y geomática
      </motion.span>

      <motion.h1
        initial={{ opacity: 0, y: 24 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.7, delay: 0.1 }}
        className="mt-6 max-w-3xl text-4xl font-extrabold leading-[1.05] text-white sm:text-5xl lg:text-6xl"
      >
        Precisión geoespacial para un desarrollo{' '}
        <span className="bg-gradient-to-r from-emerald-300 to-blue-300 bg-clip-text text-transparent">sostenible</span>
      </motion.h1>

      <motion.p
        initial={{ opacity: 0, y: 24 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.7, delay: 0.2 }}
        className="mt-6 max-w-2xl text-lg leading-relaxed text-white/80"
      >
        Integramos consultoría ambiental, geomática, LiDAR, SIG, geodesia y topografía de alta precisión
        para llevar sus proyectos de infraestructura a otro nivel.
      </motion.p>

      <motion.div
        initial={{ opacity: 0, y: 24 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.7, delay: 0.3 }}
        className="mt-9 flex flex-wrap gap-4"
      >
        <button
          onClick={() => scrollTo('servicios')}
          className="group inline-flex items-center gap-2 rounded-full bg-gradient-to-r from-emerald-500 to-blue-500 px-7 py-3.5 text-base font-semibold text-white shadow-xl shadow-emerald-500/30 transition-transform hover:-translate-y-0.5 active:scale-[0.98]"
        >
          Nuestros servicios
          <ArrowRight className="h-5 w-5 transition-transform group-hover:translate-x-1" />
        </button>
        <button
          onClick={() => scrollTo('contacto')}
          className="inline-flex items-center gap-2 rounded-full border border-white/30 bg-white/10 px-7 py-3.5 text-base font-semibold text-white backdrop-blur transition hover:bg-white/20"
        >
          <PlayCircle className="h-5 w-5" /> Solicitar cotización
        </button>
      </motion.div>

      <motion.dl
        initial={{ opacity: 0, y: 24 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.7, delay: 0.45 }}
        className="mt-14 grid max-w-3xl grid-cols-2 gap-6 sm:grid-cols-4"
      >
        {STATS.map((s) => (
          <div key={s.label} className="border-l-2 border-emerald-400/50 pl-4">
            <dt className="font-[Montserrat] text-3xl font-extrabold text-white">{s.value}</dt>
            <dd className="mt-1 text-sm text-white/70">{s.label}</dd>
          </div>
        ))}
      </motion.dl>
    </div>
  </section>
);

export default Hero;
