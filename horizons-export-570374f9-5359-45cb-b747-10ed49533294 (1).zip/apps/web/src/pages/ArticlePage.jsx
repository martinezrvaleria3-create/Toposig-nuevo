import { Link, useParams } from 'react-router-dom';
import { ArrowLeft, Calendar, Clock } from 'lucide-react';
import { POSTS } from '@/data/site';
import { formatDate } from '@/components/BlogSection';
import Seo from '@/components/Seo';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import Reveal from '@/components/Reveal';

const ArticlePage = () => {
  const { slug } = useParams();
  const post = POSTS.find((p) => p.slug === slug);
  const related = POSTS.filter((p) => p.slug !== slug).slice(0, 3);

  if (!post) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <div className="container-narrow flex min-h-[70vh] flex-col items-center justify-center text-center">
          <h1 className="text-3xl font-extrabold">Artículo no encontrado</h1>
          <p className="mt-3 text-muted-foreground">El contenido que busca no existe o fue movido.</p>
          <Link to="/#blog" className="mt-6 inline-flex items-center gap-2 rounded-full bg-emerald-500 px-6 py-3 text-sm font-semibold text-white">
            <ArrowLeft className="h-4 w-4" /> Volver al blog
          </Link>
        </div>
        <Footer />
      </div>
    );
  }

  const jsonLd = {
    '@context': 'https://schema.org',
    '@type': 'Article',
    headline: post.title,
    image: post.image,
    datePublished: post.date,
    articleSection: post.category,
    publisher: { '@type': 'Organization', name: 'TOPOSIG S.A.S.' },
  };

  return (
    <div className="min-h-screen bg-background">
      <Seo title={`${post.title} | TOPOSIG S.A.S.`} description={post.excerpt} image={post.image} type="article" jsonLd={jsonLd} />
      <Header />
      <article className="pt-[76px]">
        <div className="relative h-[46vh] min-h-[320px] w-full overflow-hidden">
          <img src={post.image} alt={`Imagen destacada: ${post.title}`} className="h-full w-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-t from-[#04231b]/90 via-[#04231b]/40 to-transparent" />
          <div className="container-narrow absolute inset-x-0 bottom-0 pb-10">
            <span className="rounded-full bg-emerald-500 px-3 py-1 text-xs font-semibold text-white">{post.category}</span>
            <h1 className="mt-4 max-w-3xl text-3xl font-extrabold leading-tight text-white sm:text-4xl">{post.title}</h1>
            <div className="mt-4 flex items-center gap-5 text-sm text-white/80">
              <span className="inline-flex items-center gap-1.5"><Calendar className="h-4 w-4" />{formatDate(post.date)}</span>
              <span className="inline-flex items-center gap-1.5"><Clock className="h-4 w-4" />{post.readTime} de lectura</span>
            </div>
          </div>
        </div>

        <div className="container-narrow py-14">
          <Link to="/#blog" className="inline-flex items-center gap-2 text-sm font-semibold text-emerald-600">
            <ArrowLeft className="h-4 w-4" /> Volver al blog
          </Link>
          <Reveal className="mt-8">
            <div className="space-y-6 text-lg leading-relaxed text-foreground/85">
              <p className="text-xl font-medium text-foreground">{post.excerpt}</p>
              {post.content.map((para, i) => <p key={i}>{para}</p>)}
            </div>
          </Reveal>
        </div>

        <section className="bg-muted/40 py-16">
          <div className="container-wide">
            <h2 className="text-2xl font-extrabold">Artículos relacionados</h2>
            <div className="mt-8 grid gap-8 md:grid-cols-3">
              {related.map((p) => (
                <Link key={p.slug} to={`/blog/${p.slug}`} className="group flex flex-col overflow-hidden rounded-3xl bg-white shadow-[0_20px_60px_-35px_rgba(10,37,64,0.4)] transition-transform hover:-translate-y-1.5">
                  <img src={p.image} alt={`Imagen del artículo: ${p.title}`} loading="lazy" className="h-44 w-full object-cover transition-transform duration-700 group-hover:scale-105" />
                  <div className="p-5">
                    <span className="text-xs font-semibold text-emerald-600">{p.category}</span>
                    <h3 className="mt-2 text-base font-bold leading-snug transition-colors group-hover:text-emerald-600">{p.title}</h3>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        </section>
      </article>
      <Footer />
    </div>
  );
};

export default ArticlePage;
