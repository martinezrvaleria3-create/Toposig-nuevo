import Seo from '@/components/Seo';
import Header from '@/components/Header';
import Hero from '@/components/Hero';
import Services from '@/components/Services';
import About from '@/components/About';
import Differentiators from '@/components/Differentiators';
import BlogSection from '@/components/BlogSection';
import Contact from '@/components/Contact';
import Footer from '@/components/Footer';
import { CONTACT } from '@/data/site';

const jsonLd = {
  '@context': 'https://schema.org',
  '@type': 'ProfessionalService',
  name: 'TOPOSIG S.A.S.',
  description: 'Consultoría ambiental, geomática, LiDAR, SIG, geodesia y topografía de alta precisión.',
  telephone: CONTACT.phone,
  email: CONTACT.email,
  address: { '@type': 'PostalAddress', addressLocality: 'Bogotá', addressCountry: 'CO', streetAddress: CONTACT.address },
  areaServed: 'Colombia',
};

const HomePage = () => (
  <div className="min-h-screen bg-background">
    <Seo jsonLd={jsonLd} />
    <Header />
    <main>
      <Hero />
      <Services />
      <About />
      <Differentiators />
      <BlogSection />
      <Contact />
    </main>
    <Footer />
  </div>
);

export default HomePage;
